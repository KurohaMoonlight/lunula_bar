// ─────────────────────────────────────────────────────────────────────────────
// FUKINAGASHI KANAGAWA BONSAI TREE & SOFT LIQUID-ENERGY NEBARI ROOTS
//   - Pangkal akar (nebari) natural: batang ramping sedikit menembus bibir atas
//     taskbar sebagai pusat akar tanpa gumpalan bulat, lalu pecah halus menjadi
//     akar penahan angin kiri & filamen panjang meruncing ke kanan.
//   - Material energi cair lembut (silky luminous liquid energy) yang menyatu
//     dengan hisapan debu emas ASLI `ambient_dust` dari `01_noise_sdf.wgsl`.
//   - Exact `min()` di dalam setiap rantai akar (ZERO benjolan ruas!) +
//     `smin_cubic()` terkontrol antar-rantai + lekukan nebari lembut.
// ─────────────────────────────────────────────────────────────────────────────

struct TreeSdfEval {
    d_trunk: f32,
    d_roots_front: f32,
    d_roots_back: f32,
    d_all: f32,
    s_prog: f32,
    perp_x: f32,
    bud_d: f32,
    root_depth: f32,
    root_arc: f32,
    root_id: f32,
    root_r: f32,
    root_nx: f32,
    root_ny: f32,
    root_energy: f32,
    root_crevice: f32,
};

/// Titik pusat batang sepanjang parameter `s` (0.0 = pusat nebari, 1.0 = kuncup puncak lightbulb).
/// Kemiringan fukinagashi ke kanan diatur lewat `u.tree_style.z` (`trunk_lean` di start.yaml).
fn tree_trunk_point(s: f32, base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let lean = clamp(u.tree_style.z, 0.15, 0.65);
    let wind_lean = pow(s, 1.15) * (rise_h * lean);
    let s_curve = sin(s * 3.14159) * (rise_h * 0.10) * smoothstep(0.0, 0.24, s);
    let gnarl = (sin(s * 4.8 + 0.4) * 0.7 + sin(s * 10.2) * 0.3) * (rise_h * 0.022) * smoothstep(0.08, 0.85, s);
    let breeze = (sin(time * 0.72 + s * 2.1) * 2.6 + cos(time * 0.43 + s * 4.5) * 1.2) * s * s;

    let x = base.x + wind_lean + s_curve + gnarl + breeze;
    let y = (base.y - 6.0) - s * rise_h;
    return vec2<f32>(x, y);
}

/// Radius batang fukinagashi berotot & berisi dengan flare nebari cekung halus menuju akar.
/// Ketebalan diatur lewat `u.tree_style.y` (`trunk_thickness` di start.yaml).
fn tree_trunk_radius(s: f32, grow: f32, time: f32) -> f32 {
    let thick = clamp(u.tree_style.y, 0.70, 2.0);
    let buttress = pow(1.0 - s, 3.8) * 7.5 * smoothstep(0.0, 0.35, grow);
    let mid_taper = mix(17.5, 4.8, pow(s, 0.70));
    let organic_var = sin(s * 13.0 + 1.1) * 0.85 + sin(s * 26.0 - 0.4) * 0.40;
    let knot = smoothstep(0.82, 1.0, sin(s * 9.5 + 2.1)) * 1.8 * (1.0 - s * 0.40);
    let breath = sin(time * 1.57 - s * 2.2) * 0.35;
    let tip_end = 1.0 - smoothstep(0.92, 1.0, s) * 0.22;
    return max((mid_taper + buttress + organic_var + knot + breath) * thick * tip_end * (0.25 + 0.75 * grow), 2.0);
}

/// Evaluasi satu rantai cabang 3-titik halus (exact min antar-segmen -> ZERO benjolan ruas).
fn eval_branch_chain3(
    p: vec2<f32>,
    p0: vec2<f32>,
    p1: vec2<f32>,
    p2: vec2<f32>,
    r0: f32,
    r1: f32,
    r2: f32,
    g: f32,
) -> f32 {
    if (g <= 0.01) {
        return 1e5;
    }
    let g0 = smoothstep(0.00, 0.55, g);
    let g1 = smoothstep(0.40, 1.00, g);
    var d = 1e5;
    if (g0 > 0.01) {
        d = min(d, sd_tapered_capsule(p, p0, mix(p0, p1, g0), r0 * g0, r1 * g0).x);
    }
    if (g1 > 0.01) {
        d = min(d, sd_tapered_capsule(p, p1, mix(p1, p2, g1), r1 * g1, r2 * g1).x);
    }
    return d;
}

/// Evaluasi satu rantai cabang 4-titik halus (exact min antar-segmen -> ZERO benjolan ruas).
fn eval_branch_chain4(
    p: vec2<f32>,
    p0: vec2<f32>,
    p1: vec2<f32>,
    p2: vec2<f32>,
    p3: vec2<f32>,
    r0: f32,
    r1: f32,
    r2: f32,
    r3: f32,
    g: f32,
) -> f32 {
    if (g <= 0.01) {
        return 1e5;
    }
    let g0 = smoothstep(0.00, 0.42, g);
    let g1 = smoothstep(0.24, 0.74, g);
    let g2 = smoothstep(0.52, 1.00, g);
    var d = 1e5;
    if (g0 > 0.01) {
        d = min(d, sd_tapered_capsule(p, p0, mix(p0, p1, g0), r0 * g0, r1 * g0).x);
    }
    if (g1 > 0.01) {
        d = min(d, sd_tapered_capsule(p, p1, mix(p1, p2, g1), r1 * g1, r2 * g1).x);
    }
    if (g2 > 0.01) {
        d = min(d, sd_tapered_capsule(p, p2, mix(p2, p3, g2), r2 * g2, r3 * g2).x);
    }
    return d;
}

/// Posisi ujung 5 percabangan dahan utama & sub-cabang pohon Fukinagashi:
fn tree_branch1_tip(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f1 = tree_trunk_point(0.35, base, rise_h, time);
    let sw = sin(time * 1.15 + 0.7) * 2.6;
    return f1 + vec2<f32>(215.0 + sw, -22.0 + sw * 0.25);
}

fn tree_branch1_sub_b(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f1 = tree_trunk_point(0.35, base, rise_h, time);
    let sw = sin(time * 1.30 + 1.2) * 2.0;
    return f1 + vec2<f32>(125.0 + sw, 18.0 + sw * 0.20);
}

fn tree_branch1_sub_c(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f1 = tree_trunk_point(0.35, base, rise_h, time);
    let sw = sin(time * 1.22 + 1.8) * 2.2;
    return f1 + vec2<f32>(165.0 + sw, -52.0 + sw * 0.22);
}

fn tree_branch2_tip(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f2 = tree_trunk_point(0.48, base, rise_h, time);
    let sw = sin(time * 1.05 + 2.3) * 2.8;
    return f2 + vec2<f32>(-94.0 + sw, -28.0 - sw * 0.20);
}

fn tree_branch2_sub_b(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f2 = tree_trunk_point(0.48, base, rise_h, time);
    let sw = sin(time * 1.18 + 2.9) * 2.2;
    return f2 + vec2<f32>(-62.0 + sw, -54.0 - sw * 0.18);
}

fn tree_branch3_tip(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f3 = tree_trunk_point(0.62, base, rise_h, time);
    let sw = sin(time * 1.25 + 3.8) * 3.0;
    return f3 + vec2<f32>(135.0 + sw, -32.0 + sw * 0.24);
}

fn tree_branch3_sub_b(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f3 = tree_trunk_point(0.62, base, rise_h, time);
    let sw = sin(time * 1.35 + 4.2) * 2.4;
    return f3 + vec2<f32>(88.0 + sw, -58.0 + sw * 0.20);
}

fn tree_branch4_tip(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f4 = tree_trunk_point(0.74, base, rise_h, time);
    let sw = sin(time * 1.12 + 4.8) * 2.4;
    return f4 + vec2<f32>(-56.0 + sw, -38.0 - sw * 0.18);
}

fn tree_branch5_tip(base: vec2<f32>, rise_h: f32, time: f32) -> vec2<f32> {
    let f5 = tree_trunk_point(0.84, base, rise_h, time);
    let sw = sin(time * 1.28 + 5.5) * 2.8;
    return f5 + vec2<f32>(82.0 + sw, -26.0 + sw * 0.22);
}

/// Kapsul meruncing dari `a` (radius `r0`) ke `b` (radius `r1`).
fn sd_tapered_capsule(p: vec2<f32>, a: vec2<f32>, b: vec2<f32>, r0: f32, r1: f32) -> vec2<f32> {
    let pa = p - a;
    let ba = b - a;
    let denom = max(dot(ba, ba), 1e-5);
    let h = clamp(dot(pa, ba) / denom, 0.0, 1.0);
    let d = length(pa - ba * h) - mix(r0, r1, h);
    return vec2<f32>(d, h);
}

/// Jarak ke segmen garis 2D
fn sd_line_seg(p: vec2<f32>, a: vec2<f32>, b: vec2<f32>) -> f32 {
    let pa = p - a;
    let ba = b - a;
    let h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-5), 0.0, 1.0);
    return length(pa - ba * h);
}

/// Akumulator energi lembut per-akar (terhubung dengan intensitas hisapan debu emas taskbar).
fn eval_root_energy(root_id: f32, time: f32, pull_act: f32) -> f32 {
    let wave1 = 0.5 + 0.5 * sin(time * (1.05 + root_id * 0.18) + root_id * 1.7 + u.start_fx.w);
    let wave2 = 0.5 + 0.5 * sin(time * (1.65 + root_id * 0.25) - root_id * 2.3);
    let base_act = clamp((pull_act - 0.35) * 0.55, 0.0, 0.75);
    return clamp((wave1 * 0.62 + wave2 * 0.38) * (0.50 + 0.50 * base_act), 0.0, 1.0);
}

/// Skala adaptif rentang akar kanan agar selalu menjalar panjang (~85% lebar taskbar) di berbagai resolusi layar.
fn root_right_span_scale(bar_w: f32) -> f32 {
    return clamp((bar_w - 96.0) / 840.0, 0.45, 1.35);
}

/// Konversi posisi segmen akar ke koordinat layar:
/// - Akar kiri bebas memeluk penuh lengkungan sudut & bahu kiri taskbar (`bar_top + 78px`)
/// - Akar kanan diskala proporsional terhadap `bar_width` dan tetap bersih di langit gelap (`bar_top + 36px`)
fn root_outline_point(
    seg_pt: vec2<f32>,
    arc: f32,
    base: vec2<f32>,
    bar_left: f32,
    bar_top: f32,
    time: f32,
) -> vec2<f32> {
    let right_scale = root_right_span_scale(u.bar_width);
    let sx = select(seg_pt.x, seg_pt.x * right_scale, seg_pt.x > 0.0);
    let x_min = bar_left + 1.0;
    let x_max = bar_left + u.bar_width - 14.0;
    let wx = clamp(base.x + sx, x_min, x_max);

    // Napas cair lembut mengalir dari ujung ke pangkal
    let gentle_breath = sin(time * 0.95 + arc * 5.2 - sx * 0.008) * 0.85 * smoothstep(0.10, 0.40, arc);
    let wy = base.y + seg_pt.y + gentle_breath;

    let min_y = mix(base.y - 30.0, bar_top - 4.0, smoothstep(0.08, 0.25, arc));
    let max_y = select(bar_top + 36.0, bar_top + 78.0, seg_pt.x < -12.0);
    return vec2<f32>(wx, clamp(wy, min_y, max_y));
}

/// Evaluasi medan tarikan akar khusus untuk mendistorsi & menyerap debu emas ASLI taskbar
/// (`ambient_dust` & gold dust dispersion di `01_noise_sdf.wgsl` + `02_taskbar_wave.wgsl`).
/// Mengembalikan `vec3(dir_to_root.x, dir_to_root.y, dist_to_root)` dalam koordinat lokal bar.
fn eval_real_dust_root_suction(
    local_p: vec2<f32>,
    bar_w: f32,
    time: f32,
) -> vec3<f32> {
    let p2_c = clamp(u.start_info.y, 0.0, 1.0);
    if (p2_c <= 0.02 || (local_p.y > 45.0 && local_p.x > 32.0)) {
        return vec3<f32>(0.0, 0.0, 1e5);
    }

    let base_local = vec2<f32>(78.0, 11.0);
    let right_scale = root_right_span_scale(bar_w);
    let seg_count = u32(clamp(u.tree_params.x, 0.0, 96.0));
    var best_d = 1e5;
    var best_pt = base_local;

    for (var i = 0u; i < seg_count; i = i + 3u) {
        let seg = roots_buf.segs[i];
        let g_seg = smoothstep(seg.stagger, min(seg.stagger + 0.30, 1.0), p2_c);
        if (g_seg <= 0.05) {
            continue;
        }
        let sxa = select(seg.a.x, seg.a.x * right_scale, seg.a.x > 0.0);
        let sxb = select(seg.b.x, seg.b.x * right_scale, seg.b.x > 0.0);
        let ax = clamp(base_local.x + sxa, 1.0, bar_w - 14.0);
        let bx = clamp(base_local.x + sxb, 1.0, bar_w - 14.0);
        let max_ya = select(36.0, 78.0, seg.a.x < -12.0);
        let max_yb = select(36.0, 78.0, seg.b.x < -12.0);
        let a = vec2<f32>(ax, clamp(base_local.y + seg.a.y, -18.0, max_ya));
        let b = mix(a, vec2<f32>(bx, clamp(base_local.y + seg.b.y, -18.0, max_yb)), g_seg);

        let pa = local_p - a;
        let ba = b - a;
        let h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-5), 0.0, 1.0);
        let cl = a + ba * h;
        let d = length(local_p - cl) - mix(seg.r0, seg.r1, h) * g_seg;
        if (d < best_d) {
            best_d = d;
            best_pt = cl;
        }
    }

    let diff = best_pt - local_p;
    let dlen = max(length(diff), 0.001);
    let dir = diff / dlen;
    return vec3<f32>(dir.x, dir.y, best_d);
}

/// Evaluasi SDF gabungan Batang Fukinagashi + Kuncup Puncak + Akar Energi Cair Kiri & Kanan
fn eval_fukinagashi_tree_sdf(
    p: vec2<f32>,
    base: vec2<f32>,
    rise_h: f32,
    p2_c: f32,
    time: f32,
    bar_left: f32,
    bar_top: f32,
) -> TreeSdfEval {
    var out = TreeSdfEval(1e5, 1e5, 1e5, 1e5, 0.0, 0.0, 1e5, 0.0, 0.0, 0.0, 1.5, 0.0, -1.0, 0.0, 0.0);
    if (p2_c <= 0.004) {
        return out;
    }

    let base_g = smoothstep(0.0, 0.36, p2_c);
    let trunk_g = smoothstep(0.08, 0.92, p2_c);
    let bud_g = smoothstep(0.68, 1.0, p2_c);
    let pull_act = clamp(u.start_fx.z, 0.35, 1.8);

    // 1. Pangkal Nebari Cekung (Root-Collar Stub) untuk fusi metaball mulus antara
    //    akar energi cair taskbar <-> pangkal batang instanced (`10_bonsai_tree.wgsl`).
    //    (Batang atas & 600-1400 ranting fukinagashi kini dirender di pipeline instanced 2.5D!)
    let thick = clamp(u.tree_style.y, 0.70, 1.65);
    let sc = clamp(rise_h / 440.0, 0.65, 1.65);
    let collar_h = 34.0 * sc * base_g;
    let c_p0 = vec2<f32>(base.x, base.y + 3.0 * sc);
    let c_p1 = vec2<f32>(base.x - 5.0 * sc, base.y - collar_h);
    let r_c0 = 26.0 * thick * sc * (0.28 + 0.72 * base_g);
    let r_c1 = 17.5 * thick * sc * (0.28 + 0.72 * base_g);

    let cap_main = sd_tapered_capsule(p, c_p0, c_p1, r_c0, r_c1);
    var d_trunk = cap_main.x;
    var best_s = cap_main.y * 0.10;
    let c_dir = normalize(c_p1 - c_p0 + vec2<f32>(0.0001, -0.0001));
    let c_perp = vec2<f32>(-c_dir.y, c_dir.x);
    var best_perp = dot(p - mix(c_p0, c_p1, cap_main.y), c_perp);

    // Dua banir samping halus kiri-kanan agar pangkal akar mengalir mulus ke batang
    let fl_l = sd_tapered_capsule(
        p,
        vec2<f32>(base.x - 28.0 * thick * sc, base.y + 1.0 * sc),
        vec2<f32>(base.x - 9.0 * sc, base.y - 24.0 * sc * base_g),
        5.5 * thick * sc * base_g,
        12.0 * thick * sc * base_g
    ).x;
    let fl_r = sd_tapered_capsule(
        p,
        vec2<f32>(base.x + 32.0 * thick * sc, base.y + 1.0 * sc),
        vec2<f32>(base.x + 8.0 * sc, base.y - 24.0 * sc * base_g),
        6.0 * thick * sc * base_g,
        12.5 * thick * sc * base_g
    ).x;
    d_trunk = smin_cubic(d_trunk, min(fl_l, fl_r), 8.5 * base_g);
    let d_bud = 1e5;

    // 3. Akar Energi Cair Fukinagashi (Kiri & Kanan):
    //    - Exact `min()` antar-segmen dalam 1 rantai -> 100% mulus tanpa benjolan ruas!
    //    - `smin_cubic()` terkontrol antar-rantai + crevice lembut di nebari.
    var d_front = 1e5;
    var r_depth = 0.0;
    var r_arc = 0.0;
    var r_id = 0.0;
    var r_rad = 1.5;
    var r_n = vec2<f32>(0.0, -1.0);
    var r_energy = 0.0;
    var r_crevice = 0.0;

    let seg_count = u32(clamp(u.tree_params.x, 0.0, 96.0));

    if (p.y > bar_top - 36.0 && p.y < bar_top + 92.0 && p.x > bar_left - 16.0 && p.x < bar_left + u.bar_width + 16.0) {
        // Distorsi domain organik halus + aliran cair pelan agar akar terasa seperti energi cair hidup
        let warp_x = sin(p.x * 0.045 + p.y * 0.040 - time * 0.65) * 0.65 + cos(p.x * 0.10 - p.y * 0.07) * 0.22;
        let warp_y = cos(p.x * 0.042 - p.y * 0.048 + time * 0.55) * 0.65 + sin(p.x * 0.09 + p.y * 0.06) * 0.22;
        let gnarl_vec = vec2<f32>(warp_x, warp_y);

        var has_chain = false;
        var cur_chain_id = -1.0;
        var d_ch = 1e5;
        var ch_depth = 0.0;
        var ch_arc = 0.0;
        var ch_id = 0.0;
        var ch_rad = 1.5;
        var ch_n = vec2<f32>(0.0, -1.0);
        var ch_en = 0.0;
        var ch_g = 0.0;

        for (var i = 0u; i < seg_count; i = i + 1u) {
            let seg = roots_buf.segs[i];

            if (has_chain && abs(seg.layer_phase - cur_chain_id) > 0.25) {
                let k_merge = select(select(3.8, 2.2, ch_depth > 0.5), 1.2, ch_depth > 1.5) * max(ch_g, 0.2);
                let near_both = clamp(1.0 - abs(d_front - d_ch) / max(k_merge * 1.25, 0.5), 0.0, 1.0)
                              * (1.0 - smoothstep(-0.5, 2.2, max(d_front, d_ch)));
                r_crevice = max(r_crevice, near_both);

                if (d_ch < d_front) {
                    r_depth = ch_depth;
                    r_arc = ch_arc;
                    r_id = ch_id;
                    r_rad = ch_rad;
                    r_n = ch_n;
                    r_energy = ch_en;
                }
                d_front = smin_cubic(d_front, d_ch, k_merge);
                has_chain = false;
                d_ch = 1e5;
            }

            let g_seg = smoothstep(seg.stagger, min(seg.stagger + 0.28, 1.0), p2_c);
            if (g_seg <= 0.005) {
                continue;
            }

            if (!has_chain) {
                has_chain = true;
                cur_chain_id = seg.layer_phase;
                d_ch = 1e5;
                ch_depth = seg.depth;
                ch_g = g_seg;
            } else {
                ch_g = max(ch_g, g_seg);
            }

            let a = root_outline_point(seg.a, seg.arc0, base, bar_left, bar_top, time);
            let b_full = root_outline_point(seg.b, seg.arc1, base, bar_left, bar_top, time);
            let b = mix(a, b_full, g_seg);

            let mid_arc = 0.5 * (seg.arc0 + seg.arc1);
            let w_amp = smoothstep(0.10, 0.32, mid_arc) * select(0.45, 0.85, seg.depth < 0.5);
            let pw = p + gnarl_vec * w_amp;

            let en = eval_root_energy(seg.root_id, time, pull_act);
            // Riak ketebalan cairan energi lembut yang merambat dari ujung (arc=1) -> pangkal (arc=0)
            let liq_ripple = 1.0 + 0.042 * sin(mid_arc * 15.0 + time * 2.4 + seg.root_id * 1.9);
            let energy_thick = 1.0 + en * 0.07 * (1.0 - seg.depth * 0.25);

            let mod_scale = liq_ripple * energy_thick;
            let rr0 = seg.r0 * g_seg * mod_scale;
            let rr1 = seg.r1 * g_seg * mod_scale;

            let cap = sd_tapered_capsule(pw, a, b, rr0, rr1);
            if (cap.x < d_ch) {
                d_ch = cap.x;
                let closest = mix(a, b, cap.y);
                ch_rad = max(mix(rr0, rr1, cap.y), 0.20);
                ch_arc = mix(seg.arc0, seg.arc1, cap.y);
                ch_id = seg.root_id;
                ch_depth = seg.depth;
                ch_en = en;
                let diff = pw - closest;
                let dlen = length(diff);
                ch_n = select(vec2<f32>(0.0, -1.0), diff / dlen, dlen > 0.001);
            }
        }

        if (has_chain) {
            let k_merge = select(select(3.8, 2.2, ch_depth > 0.5), 1.2, ch_depth > 1.5) * max(ch_g, 0.2);
            let near_both = clamp(1.0 - abs(d_front - d_ch) / max(k_merge * 1.25, 0.5), 0.0, 1.0)
                          * (1.0 - smoothstep(-0.5, 2.2, max(d_front, d_ch)));
            r_crevice = max(r_crevice, near_both);

            if (d_ch < d_front) {
                r_depth = ch_depth;
                r_arc = ch_arc;
                r_id = ch_id;
                r_rad = ch_rad;
                r_n = ch_n;
                r_energy = ch_en;
            }
            d_front = smin_cubic(d_front, d_ch, k_merge);
        }
    }

    // Fusi nebari cekung alami antara pangkal batang & pancaran akar
    let d_all = smin_cubic(d_trunk, d_front, 14.0 * base_g);

    out.d_trunk = d_trunk;
    out.d_roots_front = d_front;
    out.d_roots_back = 1e5;
    out.d_all = d_all;
    out.s_prog = best_s;
    out.perp_x = best_perp;
    out.bud_d = d_bud;
    out.root_depth = r_depth;
    out.root_arc = r_arc;
    out.root_id = r_id;
    out.root_r = r_rad;
    out.root_nx = r_n.x;
    out.root_ny = r_n.y;
    out.root_energy = r_energy;
    out.root_crevice = r_crevice;
    return out;
}

/// Material Energi Cair Lembut (Soft Translucent Liquid Energy):
/// - Meniscus amber hangat lembut (tanpa garis tepi kayu gelap kaku)
/// - Badan emas madu bercahaya dengan aliran laminar halus dari ujung akar -> pangkal batang
/// - Inti cahaya krem-emas lembut + dua gelombang energi cair bergulung halus masuk ke batang
/// - Pantulan refraksi biru langit taskbar di sisi bawah agar terasa cair & transparan
fn shade_liquid_energy_root(
    p: vec2<f32>,
    d_sdf: f32,
    rad: f32,
    nx: f32,
    ny: f32,
    arc: f32,
    root_id: f32,
    depth: f32,
    energy: f32,
    time: f32,
) -> vec3<f32> {
    let meniscus_amber = hex(86.0, 52.0, 24.0);
    let honey_deep     = hex(176.0, 118.0, 44.0);
    let liquid_gold    = hex(232.0, 180.0, 92.0);
    let energy_core    = hex(255.0, 244.0, 206.0);
    let rim_glow       = hex(255.0, 236.0, 178.0);
    let sky_refract    = hex(104.0, 158.0, 194.0);

    let eff_rad = max(rad, 0.40);
    let radial = clamp(1.0 + d_sdf / eff_rad, 0.0, 1.0);
    let core_in = 1.0 - radial;

    let nz = sqrt(max(1.0 - radial * radial * 0.90, 0.10));
    let n3 = normalize(vec3<f32>(nx * radial, ny * radial, nz));
    let light_dir = normalize(vec3<f32>(-0.30, -0.78, 0.55));
    let half_vec = normalize(light_dir + vec3<f32>(0.0, 0.0, 1.0));

    let ndl = clamp(dot(n3, light_dir) * 0.5 + 0.5, 0.0, 1.0);
    let spec = pow(max(dot(n3, half_vec), 0.0), 26.0);

    // 1. Badan cairan energi: meniscus amber lembut -> emas madu -> emas cair hangat
    var col = mix(meniscus_amber, honey_deep, smoothstep(0.0, 0.34, core_in));
    col = mix(col, liquid_gold, smoothstep(0.14, 0.66, core_in) * (0.74 + 0.26 * ndl));

    // Aliran cairan laminar lembut bergerak MASUK dari ujung (arc=1) -> pangkal (arc=0)
    let flow1 = fbm(vec2<f32>(arc * 6.5 + time * 1.15, p.y * 0.10 + root_id * 2.7));
    let flow2 = fbm(vec2<f32>(arc * 12.0 + time * 1.75, p.x * 0.05 - root_id * 1.9));
    let liq_tex = mix(flow1, flow2, 0.35);
    col = col * mix(0.92, 1.14, smoothstep(0.18, 0.82, liq_tex));

    // 2. Inti energi cair bercahaya lembut (lebih berpendar & halus daripada kayu padat)
    let soft_core = pow(core_in, 1.65) * (0.68 + 0.26 * energy);
    col = mix(col, energy_core, clamp(soft_core * (1.0 - depth * 0.10), 0.0, 0.84));

    // 3. Dua gelombang energi cair lembut yang menyerap & mengalir kontinu ke pangkal batang
    let speed1 = 0.22 + root_id * 0.03;
    let head1 = 1.0 - fract(time * speed1 + root_id * 0.29);
    let d1 = arc - head1;
    let d1w = select(d1, d1 + 1.0, d1 < -0.5);
    let swell1 = exp(-abs(d1w) * 10.5) * smoothstep(-0.22, 0.04, d1w);

    let head2 = 1.0 - fract(time * (speed1 * 1.38) + root_id * 0.61 + 0.45);
    let d2 = arc - head2;
    let d2w = select(d2, d2 + 1.0, d2 < -0.5);
    let swell2 = exp(-abs(d2w) * 14.0) * 0.65;

    let flow_pulse = clamp((swell1 + swell2) * (0.48 + 0.48 * energy), 0.0, 0.88);
    col = mix(col, energy_core, flow_pulse * (0.30 + 0.50 * core_in));

    // 4. Kilau rim atas lembut & pantulan refraksi biru taskbar di sisi bawah
    let upper_rim = clamp(-n3.y, 0.0, 1.0) * smoothstep(0.42, 0.90, radial);
    col = mix(col, rim_glow, upper_rim * (0.34 + 0.22 * flow_pulse));

    let lower_bounce = clamp(n3.y, 0.0, 1.0) * smoothstep(0.36, 0.90, radial);
    col = mix(col, sky_refract, lower_bounce * 0.26);

    // 5. Specular permukaan cair basah yang halus
    col = mix(col, energy_core, clamp(spec * (0.36 + 0.20 * energy), 0.0, 0.58));

    return col;
}

/// Shading Batang Fukinagashi dengan 3 gaya material yang bisa diganti live lewat `trunk_style` di start.yaml:
///   - `0` ("hybrid") : Kulit tepi amber-perunggu berurat lembut + inti energi cair emas (paling nyatu!)
///   - `1` ("liquid") : Energi cair emas lembut penuh selaras 100% dengan akar
///   - `2` ("wood")   : Kayu bonsai sumi-perunggu solid dengan retakan urat Kintsugi emas cair mengalir
fn shade_fukinagashi_trunk(
    p: vec2<f32>,
    ev: TreeSdfEval,
    base: vec2<f32>,
    rise_h: f32,
    p2_c: f32,
    time: f32,
    absorb_boost: f32,
) -> vec3<f32> {
    let style_id = u.tree_style.x;
    let s = clamp(ev.s_prog, 0.0, 1.0);
    let thick = clamp(u.tree_style.y, 0.70, 1.60);
    let depth_in = clamp(-ev.d_trunk / (11.5 * thick), 0.0, 1.0);
    let heartbeat = 0.5 + 0.5 * sin(time * 1.57);

    let flow_u = ev.perp_x * 0.30;
    let flow_v = s * 6.4 - time * 1.40;
    let streamlines = fbm(vec2<f32>(flow_u * 2.1, flow_v * 0.72));
    let micro_sheen = fbm(vec2<f32>(flow_u * 4.4 + 2.1, flow_v * 1.75));
    let fluid_val = mix(streamlines, micro_sheen, 0.30);

    let gold_warm = hex(232.0, 180.0, 92.0);
    let gold_core = hex(255.0, 244.0, 206.0);
    let gold_pale = hex(255.0, 250.0, 226.0);
    var col = gold_warm;

    if (style_id < 0.5) {
        // STYLE 0: HYBRID — Kulit tepi amber-perunggu berurat lembut + inti energi cair emas
        let bark_rim   = hex(52.0, 28.0, 12.0);
        let amber_bark = hex(146.0, 88.0, 32.0);
        // Kulit gelap sedikit lebih tebal di pangkal & batang bawah, menipis ke arah ujung cabang
        let bark_w = mix(0.46, 0.24, s);
        col = mix(bark_rim, amber_bark, smoothstep(0.0, bark_w, depth_in));
        let core_tint = mix(gold_warm, gold_core, smoothstep(0.14, 0.88, s));
        col = mix(col, core_tint, pow(depth_in, 0.90) * (0.76 + 0.24 * s));
        // Urat kulit halus vertikal yang mengalir menyatu ke cairan dalam
        let bark_rib = 0.92 + 0.14 * sin(ev.perp_x * 0.85 + streamlines * 4.2);
        col = col * mix(0.88, 1.14, smoothstep(0.20, 0.80, fluid_val)) * mix(bark_rib, 1.0, smoothstep(0.35, 0.85, depth_in));
    } else if (style_id < 1.5) {
        // STYLE 1: PURE SOFT LIQUID ENERGY — Cairan energi emas lembut penuh selaras akar
        let meniscus_amber = hex(86.0, 52.0, 24.0);
        let honey_deep     = hex(176.0, 118.0, 44.0);
        let sky_refract    = hex(104.0, 158.0, 194.0);
        col = mix(meniscus_amber, honey_deep, smoothstep(0.0, 0.34, depth_in));
        let core_tint = mix(gold_warm, gold_core, smoothstep(0.08, 0.85, s));
        col = mix(col, core_tint, pow(depth_in, 0.72) * (0.82 + 0.18 * s));
        col = col * mix(0.92, 1.16, smoothstep(0.18, 0.82, fluid_val));
        let edge_refract = smoothstep(0.0, 0.30, 1.0 - depth_in) * smoothstep(2.0, 9.0, ev.perp_x);
        col = mix(col, sky_refract, edge_refract * 0.22);
    } else {
        // STYLE 2: WOOD-LIKE + KINTSUGI — Kayu bonsai sumi-perunggu solid dengan urat emas cair mengalir
        let sumi_bark   = hex(28.0, 20.0, 16.0);
        let bronze_wood = hex(78.0, 48.0, 26.0);
        let warm_wood   = hex(124.0, 80.0, 42.0);
        let wood_grain = fbm(vec2<f32>(ev.perp_x * 0.55 + sin(s * 12.0) * 0.6, s * 14.0));
        col = mix(sumi_bark, bronze_wood, smoothstep(0.0, 0.45, depth_in));
        col = mix(col, warm_wood, smoothstep(0.28, 0.85, depth_in) * (0.55 + 0.45 * wood_grain));
        col = col * mix(0.80, 1.18, wood_grain);

        // Retakan urat Kintsugi emas cair yang mengalir naik dari pangkal nebari -> kuncup puncak
        let vein_n = fbm(vec2<f32>(ev.perp_x * 0.42 + 3.1, s * 9.0 - time * 0.55));
        let kintsugi_vein = smoothstep(0.62, 0.80, vein_n) * smoothstep(0.10, 0.55, depth_in);
        let vein_core = smoothstep(0.74, 0.88, vein_n) * smoothstep(0.15, 0.65, depth_in);
        col = mix(col, gold_warm, kintsugi_vein * 0.85);
        col = mix(col, gold_core, vein_core * 0.90);
        // Transisi lembut ke energi cair di sangat dekat pangkal akar & puncak
        let nebari_melt = (1.0 - smoothstep(0.0, 0.14, s)) * 0.45;
        col = mix(col, gold_warm, nebari_melt * depth_in);
    }

    // Denyut energi naik & aliran getah cahaya (sap band) menuju kuncup lightbulb
    col = mix(col, gold_core, (0.08 * heartbeat + 0.16 * absorb_boost) * depth_in);

    let sap_pos = fract(time * 0.26);
    let sap_dist = abs(s - sap_pos);
    let sap_band = exp(-sap_dist * sap_dist * 46.0) * smoothstep(0.15, 0.85, depth_in);
    let sap_pos2 = fract(time * 0.26 + 0.52);
    let sap_band2 = exp(-pow(s - sap_pos2, 2.0) * 58.0) * smoothstep(0.2, 0.9, depth_in) * 0.65;
    col = mix(col, gold_pale, clamp((sap_band + sap_band2) * 0.52, 0.0, 0.60));

    // Rim light tepi kiri-atas halus
    let side_rim = smoothstep(-2.0, -9.5, ev.perp_x) * (1.0 - smoothstep(0.0, 2.8, abs(ev.d_trunk)));
    col = mix(col, gold_pale, side_rim * (0.40 + 0.24 * s));

    // Pendaran kuncup lightbulb puncak (tetap dijaga utuh!)
    let bud_mask = 1.0 - smoothstep(-1.0, 9.0, ev.bud_d);
    let bud_glow = bud_mask * (0.68 + 0.32 * heartbeat) * smoothstep(0.65, 1.0, p2_c);
    col = mix(col, gold_pale, clamp(bud_glow, 0.0, 0.92));

    // Partikel getah emas mikro di dalam batang
    let sp = (p + vec2<f32>(sin(p.y * 0.04 + time * 1.8) * 2.0, time * 32.0)) / 3.2;
    let rs = hash21(floor(sp));
    let ds = length(fract(sp) - vec2<f32>(0.5, 0.5)) * 3.2;
    let tw = 0.5 + 0.5 * sin(time * 4.5 + rs * 12.56);
    let sap_dot = step(0.89, rs) * (1.0 - smoothstep(0.2, 1.0, ds)) * tw * depth_in;
    col = mix(col, gold_pale, sap_dot * 0.68);

    return col;
}

/// Signed distance ke satu bantalan awan jarum pinus bertingkat (Japanese Pine Foliage Pad / Tana)
fn sd_pine_foliage_pad(
    p: vec2<f32>,
    center: vec2<f32>,
    half_size: vec2<f32>,
    tilt: f32,
) -> f32 {
    let ca = cos(tilt);
    let sa = sin(tilt);
    let d = p - center;
    let q = vec2<f32>(d.x * ca + d.y * sa, -d.x * sa + d.y * ca);

    // Multi-lobed cloud: middle ellipse + left & right overlapping lobes
    let d0 = length(q / half_size) - 1.0;
    let d1 = length((q - vec2<f32>(-half_size.x * 0.44, 1.5)) / (half_size * vec2<f32>(0.66, 0.78))) - 1.0;
    let d2 = length((q - vec2<f32>( half_size.x * 0.44, 1.0)) / (half_size * vec2<f32>(0.70, 0.80))) - 1.0;
    let base_d = min(d0, min(d1, d2)) * min(half_size.x, half_size.y);
    // Needle tuft fringe along the cloud edge
    let fringe = sin(atan2(q.y, q.x) * 12.0) * 1.3;
    return base_d + fringe;
}

/// Helper komposit satu awan daun/jarum pinus rimbun bertingkat (tana)
fn blend_pine_foliage_pad(
    p: vec2<f32>,
    center: vec2<f32>,
    half_size: vec2<f32>,
    tilt: f32,
    grow: f32,
    time: f32,
    in_col: vec3<f32>,
    in_alpha: f32,
) -> vec4<f32> {
    var col = in_col;
    var alpha = in_alpha;
    if (grow <= 0.01) {
        return vec4<f32>(col, alpha);
    }
    // Fast bounding box culling
    let max_r = max(half_size.x, half_size.y) + 16.0;
    if (abs(p.x - center.x) > max_r || abs(p.y - center.y) > max_r) {
        return vec4<f32>(col, alpha);
    }

    let d_pad = sd_pine_foliage_pad(p, center, half_size * (0.65 + 0.35 * grow), tilt);
    let gold_leaf  = hex(236.0, 186.0, 96.0);
    let gold_core  = hex(255.0, 246.0, 210.0);
    let deep_pine  = hex(38.0, 30.0, 22.0);
    let bronze_mid = hex(120.0, 82.0, 38.0);

    // 1. Aura cahaya emas lembut di sekeliling awan jarum pinus
    let aura = exp(-max(d_pad, 0.0) * 0.28) * 0.24 * grow;
    if (aura > 0.002) {
        col = mix(col, gold_leaf, aura);
        alpha = max(alpha, aura * 0.82);
    }

    // 2. Badan awan daun rimbun dengan tekstur serat jarum pinus Kanagawa
    let pad_m = (1.0 - smoothstep(-0.85, 0.85, d_pad)) * grow;
    if (pad_m > 0.002) {
        let depth_in = clamp(-d_pad / max(half_size.y * 0.75, 2.0), 0.0, 1.0);
        // Serat jarum pinus searah hembusan angin fukinagashi
        let needle_flow = fbm(vec2<f32>((p.x - center.x) * 0.08 + (p.y - center.y) * 0.16, (p.y - center.y) * 0.25 - time * 0.40));
        var body_col = mix(deep_pine, bronze_mid, smoothstep(0.0, 0.45, depth_in));
        body_col = mix(body_col, gold_leaf, smoothstep(0.20, 0.85, depth_in) * (0.60 + 0.40 * needle_flow));

        // Kilau rim atas awan tertimpa cahaya matahari
        let upper_rim = (1.0 - smoothstep(0.0, 2.6, abs(d_pad))) * smoothstep(2.0, -4.0, p.y - center.y);
        body_col = mix(body_col, gold_core, upper_rim * 0.65);

        col = mix(col, body_col, pad_m * 0.94);
        alpha = max(alpha, pad_m * 0.96);
    }

    return vec4<f32>(col, alpha);
}

/// SDF 1 lembar daun jiwa emas (*soul leaf* — runcing anggun seperti daun willow/maple bercahaya).
/// Mengembalikan `vec2(d_sdf, local_y)` untuk menggambar tulang daun cahaya di tengahnya.
fn sd_soul_leaf(p: vec2<f32>, center: vec2<f32>, angle: f32, length_px: f32, width_px: f32) -> vec2<f32> {
    let ca = cos(angle);
    let sa = sin(angle);
    let d = p - center;
    let lx = d.x * ca + d.y * sa;
    let ly = -d.x * sa + d.y * ca;
    let t = clamp((lx + length_px * 0.5) / max(length_px, 1.0), 0.0, 1.0);
    let hw = width_px * sin(t * 3.14159265) * (0.85 + 0.30 * (1.0 - t));
    let dx = max(abs(lx) - length_px * 0.5, 0.0);
    let dy = abs(ly) - hw;
    let sdf = select(dy, length(vec2<f32>(dx, max(dy, 0.0))), dx > 0.0);
    return vec2<f32>(sdf, ly);
}

/// Helper komposit satu lembar daun jiwa emas berpendar (translusen emas + tulang daun krem + aura lembut).
fn blend_soul_leaf(
    p: vec2<f32>,
    center: vec2<f32>,
    angle: f32,
    len_px: f32,
    wid_px: f32,
    opacity: f32,
    shimmer: f32,
    in_col: vec3<f32>,
    in_alpha: f32,
) -> vec4<f32> {
    var col = in_col;
    var alpha = in_alpha;
    if (opacity <= 0.004 || abs(p.x - center.x) > len_px + 14.0 || abs(p.y - center.y) > len_px + 14.0) {
        return vec4<f32>(col, alpha);
    }

    let lv = sd_soul_leaf(p, center, angle, len_px, wid_px);
    let dl = lv.x;
    let gold_leaf = hex(236.0, 186.0, 96.0);
    let soul_core = hex(255.0, 248.0, 214.0);

    // Aura cahaya halus di sekitar daun jiwa
    let aura = exp(-max(dl, 0.0) * 0.34) * 0.28 * opacity * (0.85 + 0.15 * shimmer);
    if (aura > 0.002) {
        col = mix(col, gold_leaf, aura);
        alpha = max(alpha, aura * 0.82);
    }

    // Badan daun jiwa emas transparan dengan tulang daun bercahaya
    let lm = (1.0 - smoothstep(-0.85, 0.85, dl)) * opacity;
    if (lm > 0.002) {
        let vein = exp(-abs(lv.y) * 1.45) * (0.68 + 0.22 * shimmer);
        let lcol = mix(gold_leaf, soul_core, clamp(vein, 0.0, 0.94));
        col = mix(col, lcol, lm * 0.88);
        alpha = max(alpha, lm * 0.92);
    }
    return vec4<f32>(col, alpha);
}

/// Render daun jiwa emas rontok tipis melayang terbawa angin fukinagashi (tanpa gumpalan pad oval
/// agar siluet ranting bonsai winter 5-tingkat tetap 100% tajam & bersih).
fn render_soul_leaves(
    p: vec2<f32>,
    base: vec2<f32>,
    rise_h: f32,
    p2_c: f32,
    time: f32,
    in_col: vec3<f32>,
    in_alpha: f32,
) -> vec4<f32> {
    var col = in_col;
    var alpha = in_alpha;
    let leaf_intensity = clamp(u.tree_style.w, 0.0, 1.8);
    let fall_gate = smoothstep(0.75, 1.00, p2_c) * min(leaf_intensity, 1.15);
    if (fall_gate <= 0.01) {
        return vec4<f32>(col, alpha);
    }

    let sc = clamp(rise_h / 440.0, 0.65, 1.65);
    let low_q = u.tree_params.w > 0.5;
    let fall_cnt = select(6, 3, low_q);
    let size_sc = (0.78 + 0.12 * leaf_intensity) * sc;

    var origins = array<vec2<f32>, 6>(
        base + vec2<f32>(160.0 * sc, -210.0 * sc),
        base + vec2<f32>(250.0 * sc, -280.0 * sc),
        base + vec2<f32>(320.0 * sc, -330.0 * sc),
        base + vec2<f32>(120.0 * sc, -340.0 * sc),
        base + vec2<f32>(280.0 * sc, -220.0 * sc),
        base + vec2<f32>(210.0 * sc, -365.0 * sc)
    );

    for (var j = 0; j < fall_cnt; j = j + 1) {
        let fj = f32(j);
        let s1 = fly_hash1(fj * 19.7 + 2.3);
        let s2 = fly_hash1(fj * 41.3 + 7.1);
        let s3 = fly_hash1(fj * 67.9 + 11.5);

        let speed = 0.09 + 0.04 * s1;
        let life = fract(time * speed + s2);

        let drift_x = life * (150.0 + 90.0 * s3) * sc + sin(life * 9.0 + fj * 2.1) * 18.0 * sc;
        let drop_y  = life * (175.0 + 110.0 * s2) * sc + cos(life * 7.0 + fj * 1.7) * 8.0 * sc;
        let pos = origins[j] + vec2<f32>(drift_x, drop_y);

        let rot = sin(time * (2.1 + 0.5 * s1) + fj * 3.7) * 0.90 + life * (2.0 + s3);
        let flip_w = 0.36 + 0.64 * abs(cos(time * (1.8 + 0.5 * s2) + fj * 2.9));

        let fade_in = smoothstep(0.0, 0.12, life);
        let fade_out = 1.0 - smoothstep(0.70, 1.0, life);
        let op = fade_in * fade_out * fall_gate * 0.72;
        let shim = 0.5 + 0.5 * sin(time * 3.4 + fj * 4.1);

        let len_f = (10.5 + 2.2 * s1) * size_sc;
        let wid_f = (2.8 + 0.5 * s3) * flip_w * size_sc;
        let r = blend_soul_leaf(p, pos, rot, len_f, wid_f, op, shim, col, alpha);
        col = r.rgb;
        alpha = r.a;
    }

    return vec4<f32>(col, alpha);
}

/// Partikel serbuk emas halus HANYA di ujung kuncup puncak batang.
/// (Partikel yang tersedot ke akar memakai debu emas ASLI `ambient_dust` di `01_noise_sdf.wgsl` & `02_taskbar_wave.wgsl`!)
fn render_bud_gold_dust(
    p: vec2<f32>,
    base: vec2<f32>,
    rise_h: f32,
    p2_c: f32,
    time: f32,
    in_col: vec3<f32>,
    in_alpha: f32,
) -> vec4<f32> {
    var col = in_col;
    var alpha = in_alpha;

    let trunk_g = smoothstep(0.08, 0.92, p2_c);
    let tip_pt = tree_trunk_point(trunk_g, base, rise_h, time);
    if (p.y > tip_pt.y + 36.0 || p.y < tip_pt.y - 110.0 || abs(p.x - tip_pt.x) > 80.0) {
        return vec4<f32>(col, alpha);
    }

    let bud_cnt = min(u32(clamp(u.tree_params.y * 0.25, 4.0, 14.0)), 14u);
    let gold_bright = hex(242.0, 206.0, 136.0);
    let gold_pale   = hex(255.0, 248.0, 214.0);

    for (var i = 0u; i < bud_cnt; i = i + 1u) {
        let fi = f32(i);
        let seed_a = fly_hash1(fi * 17.3 + 1.1);
        let seed_b = fly_hash1(fi * 31.7 + 4.7);
        let seed_c = fly_hash1(fi * 53.1 + 9.3);

        let life = fract(time * (0.20 + 0.13 * seed_a) + seed_b);
        let spread_x = (seed_c - 0.5) * 60.0 * pow(life, 0.75) + sin(time * 2.1 + fi) * 6.0 * life;
        let lift_y = -life * (56.0 + 32.0 * seed_a);
        let pt = tip_pt + vec2<f32>(spread_x, lift_y);

        let dist = length(p - pt);
        let rad = mix(1.4, 0.55, life) * (0.7 + 0.5 * seed_c);
        let fade = sin(life * 3.14159265) * smoothstep(0.68, 1.0, p2_c);
        let speck = (1.0 - smoothstep(rad * 0.35, rad * 1.8, dist)) * fade;
        if (speck > 0.004) {
            let p_col = mix(gold_bright, gold_pale, seed_a);
            col = mix(col, p_col, speck * 0.88);
            alpha = max(alpha, speck * 0.85);
        }
    }

    return vec4<f32>(col, alpha);
}

/// Evaluasi lilitan akar energi cair 3D (Ishizuki / root-over-rock) yang tersambung langsung
/// dari akar nebari `L3` di atas tombol Windows, melilit mulus DEPAN & BELAKANG dengan kurva halus
/// (ZERO sudut poligon kaku & ZERO benjolan sambungan) sambil menjaga ikon 4-kotak 100% bersih.
fn eval_win_entangle_layer(
    p: vec2<f32>,
    win_center: vec2<f32>,
    p2_c: f32,
    hover: f32,
    cinch: f32,
    time: f32,
    is_front: bool,
) -> vec4<f32> {
    let g = smoothstep(0.12, 0.88, p2_c);
    if (g <= 0.005) {
        return vec4<f32>(1e5, 0.0, 0.0, -1.0);
    }

    // Hover: melonggar lembut (+1.8px); Klik: mengencang sesaat (-3.0px) lalu rileks via pegas YAML
    let c_off = -1.2 * g - cinch * 3.0 + hover * 1.8;
    let breath = sin(time * 1.57) * 0.45;
    let q_raw = p - win_center;
    // Distorsi organik cair sangat halus agar lilitan terasa hidup & tidak kaku
    let qw = q_raw + vec2<f32>(
        sin(q_raw.x * 0.08 + q_raw.y * 0.07 - time * 0.9) * 0.50,
        cos(q_raw.x * 0.07 - q_raw.y * 0.08 + time * 0.8) * 0.50
    ) * g;

    var d_min = 1e5;
    var best_arc = 0.0;
    var best_cl = vec2<f32>(0.0, -28.0);

    if (!is_front) {
        // ─────────────────────────────────────────────────────────────────────
        // BACK LAYER: Lilitan akar yang menyusup ke BELAKANG tombol Windows (kedalaman 3D)
        // ─────────────────────────────────────────────────────────────────────
        let g1 = smoothstep(0.10, 0.65, g);
        let g2 = smoothstep(0.32, 0.92, g);

        // Back Strand B: Masuk dari akar nebari kiri-atas L3 (-26, -18), melingkar di BELAKANG
        // sisi kiri tombol hingga muncul ke depan di kiri-bawah (-23, +21)
        var bl = array<vec2<f32>, 7>(
            vec2<f32>(-26.0, -18.0),
            vec2<f32>(-30.5 + c_off * 0.35, -10.5),
            vec2<f32>(-32.8 + c_off * 0.40, -1.0),
            vec2<f32>(-32.5 + c_off * 0.40,  8.5),
            vec2<f32>(-29.5 + c_off * 0.35, 16.5),
            vec2<f32>(-24.5 + c_off * 0.25, 22.0),
            vec2<f32>(-18.0, 25.0 - c_off * 0.25)
        );
        var bl_r = array<f32, 7>(2.70, 2.45, 2.25, 2.10, 1.95, 1.85, 1.70);
        var d_bl = 1e5;
        for (var i = 0; i < 6; i = i + 1) {
            let fi = f32(i) / 6.0;
            let sg = smoothstep(fi * 0.45, min(fi * 0.45 + 0.45, 1.0), g1);
            if (sg <= 0.01) { continue; }
            let a = bl[i];
            let b = mix(a, bl[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, bl_r[i] * sg, bl_r[i + 1] * sg);
            if (cap.x < d_bl) {
                d_bl = cap.x;
                best_cl = mix(a, b, cap.y);
                best_arc = (f32(i) + cap.y) / 6.0;
            }
        }
        d_min = d_bl;

        // Back Strand A: Kelanjutan Strand A depan yang menyelip ke BELAKANG sudut kanan-bawah
        // dan melingkar di belakang tepi bawah tombol
        var br = array<vec2<f32>, 6>(
            vec2<f32>( 25.5 - c_off * 0.30,  11.0),
            vec2<f32>( 27.5 - c_off * 0.35,  19.5),
            vec2<f32>( 22.0 - c_off * 0.30,  27.5 - c_off * 0.35),
            vec2<f32>( 11.5,                 32.2 - c_off * 0.40),
            vec2<f32>( -2.0,                 32.5 - c_off * 0.40),
            vec2<f32>(-15.5,                 29.5 - c_off * 0.30)
        );
        var br_r = array<f32, 6>(2.25, 2.00, 1.75, 1.45, 1.15, 0.80);
        var d_br = 1e5;
        var br_cl = best_cl;
        var br_arc = 0.0;
        for (var i = 0; i < 5; i = i + 1) {
            let fi = f32(i) / 5.0;
            let sg = smoothstep(fi * 0.45, min(fi * 0.45 + 0.45, 1.0), g2);
            if (sg <= 0.01) { continue; }
            let a = br[i];
            let b = mix(a, br[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, br_r[i] * sg, br_r[i + 1] * sg);
            if (cap.x < d_br) {
                d_br = cap.x;
                br_cl = mix(a, b, cap.y);
                br_arc = (f32(i) + cap.y) / 5.0;
            }
        }
        if (d_br < d_min) {
            best_cl = br_cl;
            best_arc = br_arc;
        }
        d_min = smin_cubic(d_min, d_br, 2.2);
    } else {
        // ─────────────────────────────────────────────────────────────────────
        // FRONT LAYER: 4 Sulur Akar Energi Cair Melilit Halus di DEPAN Tombol Windows
        // Tersambung tepat ke akar nebari L3 (ZERO sudut poligon & ZERO ujung tumpul!)
        // ─────────────────────────────────────────────────────────────────────
        let g1 = smoothstep(0.05, 0.62, g);
        let g2 = smoothstep(0.24, 0.88, g);
        let g3 = smoothstep(0.42, 1.00, g);

        // Front Strand A: Mengalir langsung dari nebari kanan-atas (+19, -34) -> memeluk bahu kanan
        // -> melengkung halus di sisi kanan -> menyusup mulus ke Back Strand A (+25.5, +11)
        var fa = array<vec2<f32>, 7>(
            vec2<f32>(19.0,                 -34.0),
            vec2<f32>(22.5 - c_off * 0.20,  -25.5),
            vec2<f32>(26.2 - c_off * 0.30,  -16.0),
            vec2<f32>(28.0 - c_off * 0.35,   -6.0 + breath * 0.4),
            vec2<f32>(28.2 - c_off * 0.35,    3.5),
            vec2<f32>(26.5 - c_off * 0.30,   12.0),
            vec2<f32>(23.0 - c_off * 0.25,   19.0)
        );
        var fa_r = array<f32, 7>(3.35, 3.00, 2.70, 2.45, 2.25, 2.05, 1.65);
        var d_fa = 1e5;
        var fa_cl = best_cl;
        var fa_arc = 0.0;
        for (var i = 0; i < 6; i = i + 1) {
            let fi = f32(i) / 6.0;
            let sg = smoothstep(fi * 0.42, min(fi * 0.42 + 0.48, 1.0), g1);
            if (sg <= 0.01) { continue; }
            let a = fa[i];
            let b = mix(a, fa[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, fa_r[i] * sg, fa_r[i + 1] * sg);
            if (cap.x < d_fa) {
                d_fa = cap.x;
                fa_cl = mix(a, b, cap.y);
                fa_arc = (f32(i) + cap.y) / 6.0;
            }
        }
        d_min = d_fa;
        best_cl = fa_cl;
        best_arc = fa_arc;

        // Front Strand B: Muncul dari Back Strand B di kiri-bawah (-24, +20) -> melingkar anggun
        // menyusuri bibir bawah -> naik meruncing tipis di sudut kanan-bawah
        var fb = array<vec2<f32>, 8>(
            vec2<f32>(-24.5 + c_off * 0.25,  19.5),
            vec2<f32>(-18.5 + c_off * 0.25,  24.5 - c_off * 0.30),
            vec2<f32>( -9.5,                 27.0 - c_off * 0.35 - breath * 0.5),
            vec2<f32>(  1.5,                 27.2 - c_off * 0.35),
            vec2<f32>( 12.0,                 25.0 - c_off * 0.30),
            vec2<f32>( 20.5 - c_off * 0.25,  19.5),
            vec2<f32>( 26.0 - c_off * 0.25,  11.0),
            vec2<f32>( 27.0 - c_off * 0.20,   1.5)
        );
        var fb_r = array<f32, 8>(2.10, 2.00, 1.88, 1.72, 1.48, 1.15, 0.78, 0.38);
        var d_fb = 1e5;
        var fb_cl = best_cl;
        var fb_arc = 0.0;
        for (var i = 0; i < 7; i = i + 1) {
            let fi = f32(i) / 7.0;
            let sg = smoothstep(fi * 0.45, min(fi * 0.45 + 0.45, 1.0), g2);
            if (sg <= 0.01) { continue; }
            let a = fb[i];
            let b = mix(a, fb[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, fb_r[i] * sg, fb_r[i + 1] * sg);
            if (cap.x < d_fb) {
                d_fb = cap.x;
                fb_cl = mix(a, b, cap.y);
                fb_arc = (f32(i) + cap.y) / 7.0;
            }
        }
        if (d_fb < d_min) {
            best_cl = fb_cl;
            best_arc = fb_arc;
        }
        d_min = smin_cubic(d_min, d_fb, 2.2);

        // Front Strand C: Sulur bulan sabit memeluk sudut kiri-atas langsung dari L3 (+6, -28.5)
        // hingga meruncing halus di sepanjang tepi kiri tombol (ikon 4-kotak tetap 100% bersih!)
        var fc = array<vec2<f32>, 7>(
            vec2<f32>(  6.5,                 -28.5),
            vec2<f32>( -3.0,                 -27.2 + c_off * 0.30 + breath * 0.4),
            vec2<f32>(-13.0,                 -24.8 + c_off * 0.30),
            vec2<f32>(-21.2 + c_off * 0.25,  -19.5),
            vec2<f32>(-26.0 + c_off * 0.30,  -11.0),
            vec2<f32>(-27.2 + c_off * 0.30,   -1.0),
            vec2<f32>(-25.0 + c_off * 0.25,    8.5)
        );
        var fc_r = array<f32, 7>(2.75, 2.45, 2.15, 1.80, 1.38, 0.90, 0.38);
        var d_fc = 1e5;
        var fc_cl = best_cl;
        var fc_arc = 0.0;
        for (var i = 0; i < 6; i = i + 1) {
            let fi = f32(i) / 6.0;
            let sg = smoothstep(fi * 0.42, min(fi * 0.42 + 0.48, 1.0), g1);
            if (sg <= 0.01) { continue; }
            let a = fc[i];
            let b = mix(a, fc[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, fc_r[i] * sg, fc_r[i + 1] * sg);
            if (cap.x < d_fc) {
                d_fc = cap.x;
                fc_cl = mix(a, b, cap.y);
                fc_arc = (f32(i) + cap.y) / 6.0;
            }
        }
        if (d_fc < d_min) {
            best_cl = fc_cl;
            best_arc = fc_arc;
        }
        d_min = smin_cubic(d_min, d_fc, 2.2);

        // Front Strand D: Serabut halus bercabang dari Strand B di kiri-bawah memeluk sudut kiri-bawah
        var fd = array<vec2<f32>, 5>(
            vec2<f32>(-17.5 + c_off * 0.25,  24.2 - c_off * 0.25),
            vec2<f32>(-23.0 + c_off * 0.25,  17.5),
            vec2<f32>(-26.0 + c_off * 0.25,   9.0),
            vec2<f32>(-25.5 + c_off * 0.25,   0.5),
            vec2<f32>(-22.5 + c_off * 0.20,  -6.5)
        );
        var fd_r = array<f32, 5>(1.45, 1.15, 0.85, 0.55, 0.30);
        var d_fd = 1e5;
        var fd_cl = best_cl;
        var fd_arc = 0.0;
        for (var i = 0; i < 4; i = i + 1) {
            let fi = f32(i) / 4.0;
            let sg = smoothstep(fi * 0.40, min(fi * 0.40 + 0.50, 1.0), g3);
            if (sg <= 0.01) { continue; }
            let a = fd[i];
            let b = mix(a, fd[i + 1], sg);
            let cap = sd_tapered_capsule(qw, a, b, fd_r[i] * sg, fd_r[i + 1] * sg);
            if (cap.x < d_fd) {
                d_fd = cap.x;
                fd_cl = mix(a, b, cap.y);
                fd_arc = (f32(i) + cap.y) / 4.0;
            }
        }
        if (d_fd < d_min) {
            best_cl = fd_cl;
            best_arc = fd_arc;
        }
        d_min = smin_cubic(d_min, d_fd, 1.8);
    }

    let diff = qw - best_cl;
    let dlen = length(diff);
    let best_n = select(vec2<f32>(0.0, -1.0), diff / dlen, dlen > 0.001);
    return vec4<f32>(d_min, best_arc, best_n.x, best_n.y);
}

/// Evaluasi retakan Kintsugi emas cair prosedural pada tombol Windows.
fn eval_win_kintsugi_cracks(
    p: vec2<f32>,
    win_center: vec2<f32>,
    p2_c: f32,
    win_hov: f32,
    win_flash: f32,
    win_ripple: f32,
    time: f32,
) -> vec4<f32> {
    let progress = smoothstep(0.20, 0.90, p2_c);
    if (progress <= 0.005 && win_flash <= 0.005 && win_ripple >= 0.995) {
        return vec4<f32>(0.0, 0.0, 0.0, 0.0);
    }

    let q = p - win_center;
    let d_box = sd_rounded_box(q, vec2<f32>(29.5, 29.5), 15.5);
    let inside_box = 1.0 - smoothstep(-0.5, 2.0, d_box);

    let ripple_col = hex(255.0, 238.0, 180.0);
    var ripple_a = 0.0;
    if (win_ripple < 0.99) {
        let rr = 6.0 + win_ripple * 36.0;
        let dist_c = length(q);
        let ring = (1.0 - smoothstep(0.0, 2.2, abs(dist_c - rr))) * (1.0 - win_ripple);
        ripple_a = ring * 0.72 * (1.0 - smoothstep(-1.0, 10.0, d_box));
    }

    if (progress <= 0.005 || inside_box <= 0.002) {
        return vec4<f32>(ripple_col, ripple_a);
    }

    let w1 = sin(q.x * 0.24 + q.y * 0.19) * 1.1 + cos(q.x * 0.44 - q.y * 0.32) * 0.5;
    let w2 = sin(q.y * 0.27 - q.x * 0.21) * 1.0 + cos(q.y * 0.46 + q.x * 0.30) * 0.45;
    let wq = q + vec2<f32>(w1, w2) * 0.68;

    let g1 = vec2<f32>(18.0, -21.0);
    let g2 = vec2<f32>(-18.0, 20.5);
    let g3 = vec2<f32>(-20.0, -17.0);
    let g4 = vec2<f32>(20.5, 16.5);

    var d_crack = 1e5;
    var crack_arc = 0.0;

    let p1a = clamp(progress * 1.45, 0.0, 1.0);
    let p1b = clamp(progress * 1.55 - 0.28, 0.0, 1.0);
    let p1c = clamp(progress * 1.65 - 0.52, 0.0, 1.0);
    let k1_0 = vec2<f32>(12.0, -13.0);
    let k1_1 = vec2<f32>(5.5, -10.5);
    let k1_2 = vec2<f32>(-4.0, -15.0);

    let s1a = sd_tapered_capsule(wq, g1, mix(g1, k1_0, p1a), 1.35 * p1a, 0.95 * p1a);
    let s1b = sd_tapered_capsule(wq, k1_0, mix(k1_0, k1_1, p1b), 0.95 * p1b, 0.65 * p1b);
    let s1c = sd_tapered_capsule(wq, k1_1, mix(k1_1, k1_2, p1c), 0.62 * p1c, 0.32 * p1c);
    let s1_br = sd_tapered_capsule(wq, k1_0, mix(k1_0, vec2<f32>(16.5, -3.5), p1b), 0.78 * p1b, 0.34 * p1b);

    d_crack = min(min(s1a.x, s1b.x), min(s1c.x, s1_br.x));
    crack_arc = clamp(length(q - g1) / 34.0, 0.0, 1.0);

    let p2a = clamp(progress * 1.38 - 0.08, 0.0, 1.0);
    let p2b = clamp(progress * 1.52 - 0.36, 0.0, 1.0);
    let k2_0 = vec2<f32>(-11.5, 13.5);
    let k2_1 = vec2<f32>(-2.5, 16.5);
    let s2a = sd_tapered_capsule(wq, g2, mix(g2, k2_0, p2a), 1.30 * p2a, 0.88 * p2a);
    let s2b = sd_tapered_capsule(wq, k2_0, mix(k2_0, k2_1, p2b), 0.85 * p2b, 0.38 * p2b);
    let s2_br = sd_tapered_capsule(wq, k2_0, mix(k2_0, vec2<f32>(-16.0, 4.5), p2b), 0.68 * p2b, 0.30 * p2b);
    let d2 = min(min(s2a.x, s2b.x), s2_br.x);
    if (d2 < d_crack) {
        d_crack = d2;
        crack_arc = clamp(length(q - g2) / 32.0, 0.0, 1.0);
    }

    if (progress > 0.24) {
        let p3 = clamp((progress - 0.24) * 1.55, 0.0, 1.0);
        let k3_0 = vec2<f32>(-13.5, -10.5);
        let s3a = sd_tapered_capsule(wq, g3, mix(g3, k3_0, p3), 1.18 * p3, 0.72 * p3);
        let s3b = sd_tapered_capsule(wq, k3_0, mix(k3_0, vec2<f32>(-17.0, -1.5), clamp(p3 * 1.3 - 0.3, 0.0, 1.0)), 0.68 * p3, 0.28 * p3);
        let d3 = min(s3a.x, s3b.x);
        if (d3 < d_crack) {
            d_crack = d3;
            crack_arc = clamp(length(q - g3) / 28.0, 0.0, 1.0);
        }
    }

    if (progress > 0.34) {
        let p4 = clamp((progress - 0.34) * 1.60, 0.0, 1.0);
        let k4_0 = vec2<f32>(12.5, 13.0);
        let s4a = sd_tapered_capsule(wq, g4, mix(g4, k4_0, p4), 1.15 * p4, 0.68 * p4);
        let s4b = sd_tapered_capsule(wq, k4_0, mix(k4_0, vec2<f32>(5.0, 17.5), clamp(p4 * 1.35 - 0.35, 0.0, 1.0)), 0.65 * p4, 0.30 * p4);
        let d4 = min(s4a.x, s4b.x);
        if (d4 < d_crack) {
            d_crack = d4;
            crack_arc = clamp(length(q - g4) / 26.0, 0.0, 1.0);
        }
    }

    let icon_guard = smoothstep(8.5, 14.5, length(q));

    let bronze_groove = hex(46.0, 26.0, 12.0);
    let gold_fill     = hex(228.0, 172.0, 82.0);
    let core_hot      = hex(255.0, 245.0, 206.0);

    let hover_pulse = 0.5 + 0.5 * sin(time * 4.2 - crack_arc * 6.0);
    let flow_wave = pow(0.5 + 0.5 * sin(crack_arc * 9.0 - time * 3.5), 2.4);
    let glow_boost = clamp(flow_wave * 0.42 + win_hov * (0.35 + 0.35 * hover_pulse) + win_flash * 0.95, 0.0, 1.2);

    let groove_m = (1.0 - smoothstep(0.0, 1.55, d_crack)) * progress;
    let fill_m   = (1.0 - smoothstep(-0.15, 0.80, d_crack)) * progress;
    let core_m   = (1.0 - smoothstep(-0.35, 0.30, d_crack)) * progress;
    let aura_m   = exp(-max(d_crack, 0.0) * 0.45) * (0.18 + 0.30 * win_hov + 0.42 * win_flash) * progress;

    var c_col = mix(bronze_groove, gold_fill, clamp(fill_m / max(groove_m, 0.01), 0.0, 1.0));
    c_col = mix(c_col, core_hot, clamp(core_m * 0.80 + glow_boost * 0.42 * fill_m, 0.0, 0.95));

    let crack_a = clamp(max(max(groove_m * 0.84, fill_m * 0.95), aura_m) * inside_box * (0.30 + 0.70 * icon_guard), 0.0, 0.96);

    let out_col = mix(c_col, ripple_col, clamp(ripple_a / max(crack_a + ripple_a, 0.001), 0.0, 1.0));
    let out_a = clamp(max(crack_a, ripple_a), 0.0, 0.98);
    return vec4<f32>(out_col, out_a);
}
